import sys
import pytest
import sdl2
from sdl2 import SDL_Init, SDL_Quit, SDL_INIT_VIDEO


@pytest.mark.skip("not implemented")
def test_SDL_ComposeCustomBlendMode(self, with_sdl):
    pass
