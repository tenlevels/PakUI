**uborder shaders - Hyllian 2025**

*How to install and use:*

  - Update your Retroarch shaders online to get a vanilla version of uborder inside 'shaders_glsl/bezel/';
  - On Retroarch, choose 'FULL' aspect ratio;
  - Choose your preset and enjoy.

